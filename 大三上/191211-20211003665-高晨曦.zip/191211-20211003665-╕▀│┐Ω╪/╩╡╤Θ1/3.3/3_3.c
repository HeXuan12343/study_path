#include<stdio.h>
#include<stdlib.h>
#include<sys/time.h>
#include<time.h>

void mul1(int n, float *A, float *B, float *C){
	int i, j, k;
	for(i = 0; i < n; i++)
  		for(j = 0; j < n; j++)
			for(k = 0; k < n; k++)
				C[i+j*n] += A[i+k*n] + B[k+j*n];
}

 void mul2(int n, float *A, float *B, float *C){    
 	int i, j, k;
	for(i = 0; i < n; i++)
		for(k = 0; k < n; k++)
			for(j = 0; j < n; j++)
				C[i+j*n] += A[i+k*n] + B[k+j*n];
 }

 void mul3(int n, float *A, float *B, float *C){
 	int i, j, k;
	for(j = 0; j < n; j++)
		for(i = 0; i < n; i++)
			for(k = 0; k < n; k++)
				C[i+j*n] += A[i+k*n] + B[k+j*n];
 }

 void mul4(int n, float *A, float *B, float *C){
 	int i, j, k;
	for(j = 0; j < n; j++)
		for(k = 0; k < n; k++)
			for(i = 0; i < n; i++)
				C[i+j*n] += A[i+k*n] + B[k+j*n];
 }

 void mul5(int n, float *A, float *B, float *C){
 	int i, j, k;
	for(k = 0; k < n; k++)
		for(i = 0; i < n; i++)
			for(j = 0; j < n; j++)
				C[i+j*n] += A[i+k*n] + B[k+j*n];
 }

void mul6(int n, float *A, float *B, float *C){
	int i, j, k;
	for(k = 0; k < n; k++)
		for(j = 0; j < n; j++)
			for(i = 0; i < n; i++)
				C[i+j*n] += A[i+k*n] + B[k+j*n];
}

int main(int argc, char **argv){
	int max = 1024, i, n;
	void (*orderings[]) (int, float *, float *, float *)
				= {&mul1, &mul2, &mul3, &mul4, &mul5, &mul6};
	char *names[] = {"ijk", "ikj", "jik", "jki", "kij", "kji"};

	float *A = (float *)malloc(max * max * sizeof(float));
	float *B = (float *)malloc(max * max * sizeof(float));
	float *C = (float *)malloc(max * max * sizeof(float));

	struct timeval start, end;

	for(i = 0; i< max*max; i++) A[i] = drand48()*2-1;
  	for(i = 0; i< max*max; i++) B[i] = drand48()*2-1;      
	for(i = 0; i< max*max; i++) C[i] = 0;

	for(i = 0; i < 6; i++){
		gettimeofday(& start, NULL);
		(* orderings[i])(max, A, B, C);
		gettimeofday(& end, NULL);

		double seconds = (end.tv_sec - start.tv_sec) + 1.0e-6 * (end.tv_usec - start.tv_usec);
		printf("%s:\tn = %d, %.3f s\n", names[i], max, seconds);
	}
}
