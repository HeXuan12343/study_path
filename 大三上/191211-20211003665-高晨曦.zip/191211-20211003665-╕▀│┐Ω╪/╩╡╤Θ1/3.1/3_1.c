#include<stdio.h>

int main()
{
  int a = 2021, b = 191;
  printf("before: a=%d  b=%d\n", a, b);  
  a ^= b;
  b ^= a;
  a ^= b;
  printf("after: a=%d  b=%d\n", a, b);
}
