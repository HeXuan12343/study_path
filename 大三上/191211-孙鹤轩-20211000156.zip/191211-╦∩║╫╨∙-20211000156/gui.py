import cv2
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from PIL import ImageTk, Image as im
from tkinter import *
from tkinter import filedialog
import cv2 as cv
import numpy as np
import pywt


plt.rcParams['font.sans-serif'] = ['SimHei']  # 设置中文字体为SimHei

def main():#创建主窗口
    def goto(num):
        if num == 1:
            main_window.destroy()
            one()
        elif num == 2:
            main_window.destroy()
            two()
        elif num == 3:
            main_window.destroy()
            three()
        elif num == 4:
            main_window.destroy()
            four()
        elif num == 5:
            main_window.destroy()
            five()
    main_window = Tk()
    main_window.title("主窗口")
    main_window.geometry("1024x600+600+200")
    #创建按钮
    Button(main_window, text="直方图均衡化", command=lambda: goto(1),width=50 , height=4).pack(pady=10)
    Button(main_window, text="频率域滤波", command=lambda: goto(2) , width=50 , height=4).pack(pady=10)
    Button(main_window, text="空域滤波", command=lambda: goto(3) , width=50 , height=4).pack(pady=10)
    Button(main_window, text="图像去噪", command=lambda: goto(4) , width=50 , height=4).pack(pady=10)
    Button(main_window, text="小波变换", command=lambda: goto(5) , width=50 , height=4).pack(pady=10)
    main_window.mainloop()

file_path = ""

'''
生成噪声
'''
def add_gaussian_noise(image, mean=0, stddev=1):
    noisy_image = image.copy()
    noise = np.random.normal(mean, stddev, noisy_image.shape).astype(np.uint8)
    noisy_image = cv.add(noisy_image, noise)
    return noisy_image

def add_salt_and_pepper_noise(image, amount=0.1):
    noisy_image = image.copy()
    num_salt = np.ceil(amount * noisy_image.size * 0.5)
    num_pepper = np.ceil(amount * noisy_image.size * 0.5)
    height, width = noisy_image.shape

    coords_salt = [np.random.randint(0, height, int(num_salt)),
                   np.random.randint(0, width, int(num_salt))]
    coords_pepper = [np.random.randint(0, height, int(num_pepper)),
                     np.random.randint(0, width, int(num_pepper))]

    noisy_image[tuple(coords_salt)] = 255
    noisy_image[tuple(coords_pepper)] = 0
    return noisy_image


def one():#直方图均衡化
    #返回主菜单
    def back():
        one_window.destroy()
        main()
    global file_path
    open_file()
    img = cv.imread(file_path , 0)
    hist1 = cv.calcHist([img],[0],None,[256],[0,256])
    img = cv.cvtColor(img , cv.COLOR_BGR2RGB)
    fig= plt.figure(figsize=(14 , 6))
    plt.subplot(2,3,1);plt.imshow(img)
    plt.subplot(2,3,2);plt.plot(hist1)
    plt.subplot(2,3,3);plt.hist(img.ravel(),256)
    #均衡化后
    img2 = cv.imread(file_path , 0)
    hist2 = cv.equalizeHist(img2)
    hist2 = cv.cvtColor(hist2 , cv.COLOR_BGR2RGB)
    plt.subplot(2,3,4);plt.imshow(hist2)
    plt.subplot(2,3,6);plt.hist(hist2.ravel(),256)#直方图

    #在新窗口中显示
    one_window = Toplevel()
    #添加菜单栏
    menu_bar = Menu()
    menu = Menu(menu_bar, tearoff=0)
    menu.add_command(label="返回主菜单", command=lambda: back())
    menu_bar.add_cascade(label="菜单", menu=menu)
    one_window.config(menu=menu_bar)
    canvas = FigureCanvasTkAgg(plt.gcf(), master=one_window)
    canvas.draw()
    canvas.get_tk_widget().pack()
    one_window.attributes("-topmost", True)
    one_window.mainloop()


'''
图像平滑处理
'''
#理想低通滤波器
def create_ideal_lowpass_filter(image, frequency):
    # 获取图像的行数和列数
    rows, cols = image.shape

    # 计算图像中心点的坐标
    crow, ccol = rows // 2, cols // 2

    # 创建一个与图像大小相同的全零数组作为掩膜
    mask = np.zeros((rows, cols), np.uint8)

    # 在掩膜中心的正方形区域中设置为1，其余部分为0
    mask[crow - frequency:crow + frequency, ccol - frequency:ccol + frequency] = 1

    # 将图像与掩膜相乘，实现低通滤波效果
    filtered_image = image * mask

    return filtered_image

#巴特沃斯低通滤波器
def create_blft_lowpass_filter(fshift, D0, n):
    # 获取频域图像的行数和列数
    rows, cols = fshift.shape

    # 计算频域图像中心点的坐标
    crow, ccol = rows // 2, cols // 2

    # 创建一个与频域图像大小相同的全零数组作为滤波器
    H = np.zeros((rows, cols))

    # 遍历频域图像中的每个位置
    for u in range(rows):
        for v in range(cols):
            # 计算当前位置到中心点的距离
            D = np.sqrt(((u - crow) ** 2 + (v - ccol) ** 2))

            # 根据巴特沃斯滤波器公式计算频域滤波器的值
            H[u, v] = 1 / (1 + (D / D0) ** (2 * n))

    # 将频域图像与滤波器相乘，实现低通滤波效果
    filtered_fshift = fshift * H

    return filtered_fshift

#高斯低通滤波器
def create_gaussian_lowpass_filter(fshift, sigma):
    # 获取频域图像的行数和列数
    rows, cols = fshift.shape

    # 计算频域图像中心点的坐标
    crow, ccol = rows // 2, cols // 2

    # 创建一个与频域图像大小相同的全零数组作为滤波器
    mask = np.zeros((rows, cols), np.float32)

    # 遍历频域图像中的每个位置
    for i in range(rows):
        for j in range(cols):
            # 计算当前位置到中心点的距离的平方
            distance_squared = (i - crow) ** 2 + (j - ccol) ** 2

            # 根据高斯滤波器公式计算频域滤波器的值
            mask[i, j] = np.exp(-distance_squared / (2 * sigma ** 2))

    # 将频域图像与滤波器相乘，实现低通滤波效果
    filtered_fshift = fshift * mask

    return filtered_fshift

'''
图像锐化处理
'''
#理想高通滤波器
def create_ideal_highpass_filter(fshift, frequency):
    # 获取频域图像的行数和列数
    rows, cols = fshift.shape

    # 计算频域图像中心点的坐标
    crow, ccol = rows // 2, cols // 2

    # 创建一个与频域图像大小相同的全1数组作为滤波器
    mask = np.ones((rows, cols), np.uint8)

    # 在中心的正方形区域中将滤波器值设为0，其余部分为1，实现高通滤波效果
    mask[crow - frequency:crow + frequency, ccol - frequency:ccol + frequency] = 0

    # 将频域图像与滤波器相乘，实现高通滤波效果
    filtered_fshift = fshift * mask

    return filtered_fshift

#巴特沃夫高通滤波器
def create_blft_highpass_filter(fshift, D0, n):
    # 获取频域图像的行数和列数
    rows, cols = fshift.shape

    # 计算频域图像中心点的坐标
    crow, ccol = rows // 2, cols // 2

    # 创建一个与频域图像大小相同的全零数组作为滤波器
    H = np.zeros((rows, cols))

    # 遍历频域图像中的每个位置
    for u in range(rows):
        for v in range(cols):
            # 计算当前位置到中心点的距离
            D = np.sqrt(((u - crow) ** 2 + (v - ccol) ** 2))

            # 根据巴特沃夫高通滤波器公式计算频域滤波器的值
            H[u, v] = 1 / (1 + (D0 / D) ** (2 * n))

    # 将频域图像与滤波器相乘，实现高通滤波效果
    filtered_fshift = fshift * H

    return filtered_fshift


#高斯高通滤波器
def create_gaussian_highpass_filter(fshift, sigma):
    # 获取频域图像的行数和列数
    rows, cols = fshift.shape

    # 计算频域图像中心点的坐标
    crow, ccol = rows // 2, cols // 2

    # 创建一个与频域图像大小相同的全零数组作为滤波器
    mask = np.zeros((rows, cols), np.float32)

    # 遍历频域图像中的每个位置
    for i in range(rows):
        for j in range(cols):
            # 计算当前位置到中心点的距离的平方
            distance_squared = (i - crow) ** 2 + (j - ccol) ** 2

            # 根据高斯高通滤波器公式计算频域滤波器的值
            mask[i, j] = 1 - np.exp(-distance_squared / (2 * sigma ** 2))

    # 将频域图像与滤波器相乘，实现高通滤波效果
    filtered_fshift = fshift * mask

    return filtered_fshift


def two():
    # 返回主菜单
    def back():
        two_window.destroy()
        main()

    global file_path
    open_file()
    image = cv.imread(file_path, 0)
    # 对图像进行傅里叶变换
    f = np.fft.fft2(image)
    fshift = np.fft.fftshift(f)

    # 理想低通滤波器
    fshift_ideal_low_filtered = create_ideal_lowpass_filter(fshift, 10)
    # 巴特沃夫低通滤波器
    fshift_blpf_low_filtered = create_blft_lowpass_filter(fshift, 10, 2)
    # 高斯低通滤波器
    fshift_gaussian_low_filtered = create_gaussian_lowpass_filter(fshift, 10)
    # 理想高通滤波器
    fshift_ideal_high_filtered = create_ideal_highpass_filter(fshift, 10)
    # 巴特沃夫高通滤波器
    fshift_blpf_high_filtered = create_blft_highpass_filter(fshift, 10, 2)
    # 高斯高通滤波器
    fshift_gaussian_high_filtered = create_gaussian_highpass_filter(fshift, 10)

    # 对滤波后的频率域图像进行逆变换
    f_ishift_ideal_low = np.fft.ifftshift(fshift_ideal_low_filtered)
    image_filtered_ideal_low = np.fft.ifft2(f_ishift_ideal_low)
    image_filtered_ideal_low = np.abs(image_filtered_ideal_low)

    f_ishift_blpf_low = np.fft.ifftshift(fshift_blpf_low_filtered)
    image_filtered_blpf_low = np.fft.ifft2(f_ishift_blpf_low)
    image_filtered_blpf_low = np.abs(image_filtered_blpf_low)

    f_ishift_gaussian_low = np.fft.ifftshift(fshift_gaussian_low_filtered)
    image_filtered_gaussian_low = np.fft.ifft2(f_ishift_gaussian_low)
    image_filtered_gaussian_low = np.abs(image_filtered_gaussian_low)

    f_ishift_ideal_high = np.fft.ifftshift(fshift_ideal_high_filtered)
    image_filtered_ideal_high = np.fft.ifft2(f_ishift_ideal_high)
    image_filtered_ideal_high = np.abs(image_filtered_ideal_high)

    f_ishift_blpf_high = np.fft.ifftshift(fshift_blpf_high_filtered)
    image_filtered_blpf_high = np.fft.ifft2(f_ishift_blpf_high)
    image_filtered_blpf_high = np.abs(image_filtered_blpf_high)

    f_ishift_gaussian_high = np.fft.ifftshift(fshift_gaussian_high_filtered)
    image_filtered_gaussian_high = np.fft.ifft2(f_ishift_gaussian_high)
    image_filtered_gaussian_high = np.abs(image_filtered_gaussian_high)

    # 显示原始图像和滤波后的图像
    fig = plt.figure(figsize=(12, 8))
    plt.subplot(331), plt.imshow(image, cmap='gray')
    plt.title('原始图片'), plt.xticks([]), plt.yticks([])
    plt.subplot(332), plt.imshow(image_filtered_ideal_low, cmap='gray')
    plt.title('理想低通滤波器'), plt.xticks([]), plt.yticks([])
    plt.subplot(333), plt.imshow(image_filtered_blpf_low, cmap='gray')
    plt.title('巴特沃夫低通滤波器'), plt.xticks([]), plt.yticks([])
    plt.subplot(334), plt.imshow(image_filtered_gaussian_low, cmap='gray')
    plt.title('高斯低通滤波器'), plt.xticks([]), plt.yticks([])
    plt.subplot(335), plt.imshow(image_filtered_ideal_high, cmap='gray')
    plt.title('理想高通滤波器'), plt.xticks([]), plt.yticks([])
    plt.subplot(336), plt.imshow(image_filtered_blpf_high, cmap='gray')
    plt.title('巴特沃夫高通滤波器'), plt.xticks([]), plt.yticks([])
    plt.subplot(337), plt.imshow(image_filtered_gaussian_high, cmap='gray')
    plt.title('高斯高通滤波器'), plt.xticks([]), plt.yticks([])

    # 在新窗口中显示
    two_window = Toplevel()
    # 添加菜单栏
    menu_bar = Menu()
    menu = Menu(menu_bar, tearoff=0)
    menu.add_command(label="返回主菜单", command=lambda: back())
    menu_bar.add_cascade(label="菜单", menu=menu)
    two_window.config(menu=menu_bar)
    canvas = FigureCanvasTkAgg(plt.gcf(), master=two_window)
    canvas.draw()
    canvas.get_tk_widget().pack()
    two_window.attributes("-topmost", True)
    two_window.mainloop()

'''
空域平滑滤波
'''
#均值滤波
def mean_filter(image, kernel_size):
    return cv2.blur(image, (kernel_size, kernel_size))

#高斯滤波
def gaussian_filter(image, kernel_size, sigma):
    return cv2.GaussianBlur(image, (kernel_size, kernel_size), sigma)

#中值滤波
def median_filter(image, kernel_size):
    return cv2.medianBlur(image, kernel_size)

#阈值邻域平滑滤波,T为阈值
def thresh_aver_filter(img_noise,T):
    img_aver = cv2.blur(img_noise,(5,5))
    row,col = img_noise.shape
    img_thresh = np.zeros((row , col))
    for i in range(row):
        for j in range(col):
            if np.abs(img_noise[i,j]-img_aver[i,j]) > T:
                img_thresh[i,j] = img_aver[i,j]
            else:
                img_thresh[i,j] = img_noise[i,j]
    return img_thresh

'''
空域锐化滤波
'''

#一阶微分算子gradient_type为方向选择水平，垂直，水平垂直
def first_order_derivative(image, gradient_type):
    if gradient_type == 'horizontal':
        gradient = cv2.Sobel(image, cv2.CV_64F, 1, 0, ksize=3)
    elif gradient_type == 'vertical':
        gradient = cv2.Sobel(image, cv2.CV_64F, 0, 1, ksize=3)
    elif gradient_type == 'horizontal_vertical':
        gradient_x = cv2.Sobel(image, cv2.CV_64F, 1, 0, ksize=3)
        gradient_y = cv2.Sobel(image, cv2.CV_64F, 0, 1, ksize=3)
        gradient = np.sqrt(gradient_x**2 + gradient_y**2)
    else:
        raise ValueError("Invalid gradient type. Supported types: 'horizontal', 'vertical', 'horizontal_vertical'.")

    return gradient

#二阶微分算子operator_type为算子类型，分为锐化和增强
def laplacian_operator(image, operator_type):
    laplacian = cv2.Laplacian(image, cv2.CV_64F)

    if operator_type == 'filter':
        filtered_image = np.clip(image + laplacian, 0, 255).astype(np.uint8)
        return filtered_image
    elif operator_type == 'enhance':
        enhanced_image = np.clip(image - laplacian, 0, 255).astype(np.uint8)
        return enhanced_image
    else:
        raise ValueError("Invalid operator type. Supported types: 'filter', 'enhance'.")
def three():
    # 返回主菜单
    def back():
        three_window.destroy()
        main()

    global file_path
    open_file()
    image = cv2.imread(file_path, 0)

    # 添加高斯噪声
    noisy_image = add_gaussian_noise(image, mean=0, stddev=2)

    # 进行均值滤波
    filtered_image_mean = cv2.blur(noisy_image, (5, 5))

    # 进行高斯滤波
    filtered_image_gaussian = cv2.GaussianBlur(noisy_image, (5, 5), 0)

    # 进行中值滤波
    filtered_image_median = cv2.medianBlur(noisy_image, 5)

    # 进行阈值邻域平滑滤波
    threshold = 10
    filtered_image_thresh_aver = thresh_aver_filter(noisy_image, threshold)

    # 一阶微分处理
    gradient_horizontal = first_order_derivative(noisy_image, 'horizontal')
    gradient_vertical = first_order_derivative(noisy_image, 'vertical')
    gradient_horizontal_vertical = first_order_derivative(noisy_image, 'horizontal_vertical')

    # 二阶微分处理
    laplacian_sharpened = laplacian_operator(noisy_image, 'filter')
    laplacian_enhanced = laplacian_operator(noisy_image, 'enhance')

    # 显示原始图像和滤波后的图像
    fig = plt.figure(figsize=(12, 8))
    plt.subplot(341), plt.imshow(image, cmap='gray')
    plt.title('原始图片'), plt.xticks([]), plt.yticks([])
    plt.subplot(342), plt.imshow(noisy_image, cmap='gray')
    plt.title('添加高斯噪声'), plt.xticks([]), plt.yticks([])
    plt.subplot(343), plt.imshow(filtered_image_mean, cmap='gray')
    plt.title('均值滤波'), plt.xticks([]), plt.yticks([])
    plt.subplot(345), plt.imshow(filtered_image_gaussian, cmap='gray')
    plt.title('高斯滤波'), plt.xticks([]), plt.yticks([])
    plt.subplot(346), plt.imshow(filtered_image_median, cmap='gray')
    plt.title('中值滤波'), plt.xticks([]), plt.yticks([])
    plt.subplot(347), plt.imshow(filtered_image_thresh_aver, cmap='gray')
    plt.title('阈值邻域平滑滤波'), plt.xticks([]), plt.yticks([])
    plt.subplot(348), plt.imshow(gradient_horizontal, cmap='gray')
    plt.title('水平一阶微分'), plt.xticks([]), plt.yticks([])
    plt.subplot(349), plt.imshow(gradient_vertical, cmap='gray')
    plt.title('垂直一阶微分'), plt.xticks([]), plt.yticks([])
    plt.subplot(3,4,10), plt.imshow(gradient_horizontal_vertical, cmap='gray')
    plt.title('水平垂直一阶微分'), plt.xticks([]), plt.yticks([])
    plt.subplot(3,4,11), plt.imshow(laplacian_sharpened, cmap='gray')
    plt.title('拉普拉斯滤波图像'), plt.xticks([]), plt.yticks([])
    plt.subplot(3,4,12), plt.imshow(laplacian_enhanced, cmap='gray')
    plt.title('拉普拉斯锐化增强图像'), plt.xticks([]), plt.yticks([])

    # 在新窗口中显示
    three_window = Toplevel()
    # 添加菜单栏
    menu_bar = Menu()
    menu = Menu(menu_bar, tearoff=0)
    menu.add_command(label="返回主菜单", command=lambda: back())
    menu_bar.add_cascade(label="菜单", menu=menu)
    three_window.config(menu=menu_bar)
    canvas = FigureCanvasTkAgg(fig, master=three_window)
    canvas.draw()
    canvas.get_tk_widget().pack()
    three_window.attributes("-topmost", True)
    three_window.mainloop()

def four():#图像去噪
    # 返回主菜单
    def back():
        four_window.destroy()
        main()

    global file_path
    open_file()
    image = cv.imread(file_path, 0)
    # 生成高斯噪声
    gaussian_image = image.copy()
    gaussian_noisy_image = add_gaussian_noise(gaussian_image)

    #生成椒盐噪声
    salt_and_pepper_noisy_image = image.copy()
    salt_and_pepper_noisy_image = add_salt_and_pepper_noise(salt_and_pepper_noisy_image)

    #对高斯噪声去噪
    gaussian_denoisy_image = cv.GaussianBlur(gaussian_noisy_image, (9, 9), 0)

    #对椒盐噪声去噪
    salt_and_pepper_denoisy_image = cv.medianBlur(salt_and_pepper_noisy_image, 5)


    # 显示原始图像和滤波后的图像
    fig = plt.figure(figsize=(14, 6))
    plt.subplot(231), plt.imshow(image, cmap='gray')
    plt.title('原始图片'), plt.xticks([]), plt.yticks([])
    plt.subplot(232), plt.imshow(gaussian_noisy_image, cmap='gray')
    plt.title('添加高斯噪声'), plt.xticks([]), plt.yticks([])
    plt.subplot(233), plt.imshow(salt_and_pepper_noisy_image, cmap='gray')
    plt.title('添加椒盐噪声'), plt.xticks([]), plt.yticks([])
    plt.subplot(235), plt.imshow(gaussian_denoisy_image, cmap='gray')
    plt.title('高斯滤波'), plt.xticks([]), plt.yticks([])
    plt.subplot(236), plt.imshow(salt_and_pepper_denoisy_image, cmap='gray')
    plt.title('中值滤波'), plt.xticks([]), plt.yticks([])

    # 在新窗口中显示
    four_window = Toplevel()
    # 添加菜单栏
    menu_bar = Menu()
    menu = Menu(menu_bar, tearoff=0)
    menu.add_command(label="返回主菜单", command=lambda: back())
    menu_bar.add_cascade(label="菜单", menu=menu)
    four_window.config(menu=menu_bar)
    canvas = FigureCanvasTkAgg(plt.gcf(), master=four_window)
    canvas.draw()
    canvas.get_tk_widget().pack()
    four_window.attributes("-topmost", True)
    four_window.mainloop()

def five():
    # 返回主菜单
    def back():
        five_window.destroy()
        main()

    global file_path
    open_file()
    image = cv2.imread(file_path, 0)

    # 生成高斯噪声
    gaussian_image = image.copy()
    gaussian_noisy_image = add_gaussian_noise(gaussian_image)

    # 小波变换
    coeffs = pywt.dwt2(gaussian_noisy_image, "haar")

    # 提取小波系数
    cA, (cH, cV, cD) = coeffs

    # 去噪处理
    threshold = 200  # 噪声阈值
    cA_thresholded = pywt.threshold(cA, threshold, mode='soft')
    cH_thresholded = pywt.threshold(cH, threshold, mode='soft')
    cV_thresholded = pywt.threshold(cV, threshold, mode='soft')
    cD_thresholded = pywt.threshold(cD, threshold, mode='soft')

    # 逆变换
    thresholded_coeffs = cA_thresholded, (cH_thresholded, cV_thresholded, cD_thresholded)
    reconstructed_image = pywt.idwt2(thresholded_coeffs, "haar")

    # 显示原始图像、变换后的图像和逆变换后的图像
    fig = plt.figure(figsize=(12, 6))
    plt.subplot(241), plt.imshow(image, cmap='gray')
    plt.title('原始图片'), plt.xticks([]), plt.yticks([])
    plt.subplot(242), plt.imshow(gaussian_noisy_image, cmap='gray')
    plt.title('添加高斯噪声'), plt.xticks([]), plt.yticks([])
    plt.subplot(243), plt.imshow(cA, cmap='gray')
    plt.title('变换后的图像cA'), plt.xticks([]), plt.yticks([])
    plt.subplot(244), plt.imshow(cH, cmap='gray')
    plt.title('变换后的图像cH'), plt.xticks([]), plt.yticks([])
    plt.subplot(245), plt.imshow(cV, cmap='gray')
    plt.title('变换后的图像cV'), plt.xticks([]), plt.yticks([])
    plt.subplot(246), plt.imshow(cD, cmap='gray')
    plt.title('变换后的图像cD'), plt.xticks([]), plt.yticks([])
    plt.subplot(247), plt.imshow(reconstructed_image, cmap='gray')
    plt.title('逆变换后的图像'), plt.xticks([]), plt.yticks([])

    # 在新窗口中显示
    five_window = Toplevel()
    # 添加菜单栏
    menu_bar = Menu()
    menu = Menu(menu_bar, tearoff=0)
    menu.add_command(label="返回主菜单", command=lambda: back())
    menu_bar.add_cascade(label="菜单", menu=menu)
    five_window.config(menu=menu_bar)
    canvas = FigureCanvasTkAgg(fig, master=five_window)
    canvas.draw()
    canvas.get_tk_widget().pack()
    five_window.attributes("-topmost", True)
    five_window.mainloop()


def open_file():
    global file_path
    file_path = filedialog.askopenfilename(filetypes=[("图像文件", "*.jpg *.png *.bmp")] , initialdir = 'E:\Python\Code\picture_process\image')

main()


