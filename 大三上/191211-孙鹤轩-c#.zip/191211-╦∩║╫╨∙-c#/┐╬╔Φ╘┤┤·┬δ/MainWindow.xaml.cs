﻿using System;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Threading;

namespace Record_16
{
    /// <summary>
    /// MainWindow.xaml 的交互逻辑
    /// </summary>
    public partial class MainWindow : Window
    {

        private DispatcherTimer timer = new DispatcherTimer();
        private int firstLevelValue = 0;
        private int secondLevelValue = 0;
        private int multiple = 100000;
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Timer_Tick(object sender, EventArgs e)
        {
            
            if(prograssBar2.Value == prograssBar2.Maximum)
            {
                prograssBar1.Value += prograssBar1.Maximum / 10;
            }
            prograssBar1.Value += firstLevelValue;
            prograssBar2.Value += secondLevelValue;
            currentVal1.Text = prograssBar1.Value.ToString();
            currentVal2.Text = prograssBar2.Value.ToString();
        }

        private void Button_Click1(object sender, RoutedEventArgs e)
        {
            int max1 = int.Parse(input1.Text);
            int max2 = int.Parse(input2.Text);
            prograssBar1.Maximum = max1;
            prograssBar2.Maximum = max2;
            if(max1 <= 0)
            {
                MessageBox.Show("请输入正确的级值！");
                return;
            }
            firstLevelValue = max1 / max1;
            secondLevelValue = firstLevelValue * multiple;
            timer.Interval = new TimeSpan(0, 0, 1);
            timer.Tick += Timer_Tick;
            Task.Run(() =>
            {
                timer.Start();
            });
        }

        private void Button_Click2(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void restartButton_Click(object sender, RoutedEventArgs e)
        {
            timer.Stop();
            input1.Text = 0.ToString();
            input2.Text = 0.ToString();
            prograssBar1.Value = 0;
            prograssBar2.Value = 0;
            currentVal1.Text = 0.ToString();
            currentVal2.Text = 0.ToString();
        }

    }

}
